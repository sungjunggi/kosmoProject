package com.fproject.attendence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class FinalYeongmookApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalYeongmookApplication.class, args);

	}

}
