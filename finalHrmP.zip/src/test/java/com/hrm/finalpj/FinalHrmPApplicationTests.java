package com.hrm.finalpj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalHrmPApplicationTests {

	@Test
	void contextLoads() {
	}

}
