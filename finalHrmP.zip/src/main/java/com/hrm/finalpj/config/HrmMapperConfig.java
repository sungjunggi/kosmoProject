package com.hrm.finalpj.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hrm.finalpj.mapper.IHrmMapper;

@Configuration
public class HrmMapperConfig {

	
}
